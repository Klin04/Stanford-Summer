// This is the .cpp file you will edit and turn in.
// We have provided a skeleton for you,
// but you must finish it as described in the spec.
// Also remove these comments here and add your own.
// TODO: remove this comment header

#include "TileStack.h"
#include "strlib.h"

TileStack::TileStack() {
    // TODO: implement this constructor
}

TileStack::~TileStack() {
    // TODO: implement this destructor
}

void TileStack::pushTile(int x, int y, int width, int height, string color) {
    // TODO: implement this member
}

void TileStack::drawAll(GWindow& window) const {
    // TODO: implement this member
}

void TileStack::highlight(int x, int y) {
    // TODO: implement this member
}

void TileStack::raise(int x, int y) {
    // TODO: implement this member
}

void TileStack::remove(int x, int y) {
    // TODO: implement this member
}

void TileStack::clear() {
    // TODO: implement this member
}
