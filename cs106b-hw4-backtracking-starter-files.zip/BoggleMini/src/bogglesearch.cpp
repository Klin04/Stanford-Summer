// This is the .cpp file you will edit and turn in.
// We have provided a skeleton for you,
// but you must finish it as described in the spec.
// Also remove these comments here and add your own.
// TODO: remove this comment header

// Please feel free to add any other #includes you need!
#include <string>
#include "boggle.h"
#include "grid.h"
#include "lexicon.h"
#include "strlib.h"
using namespace std;

// TODO: comment this function
bool humanWordSearch(Grid<char>& board, string word) {
    // TODO: write this function
    return false;
}

// TODO: comment this function
Set<string> computerWordSearch(Grid<char>& board, Lexicon& dictionary) {
    // TODO: write this function
    Set<string> allWords;
    return allWords;
}
