// This is the .cpp file you will edit and turn in.
// We have provided a skeleton for you,
// but you must finish it as described in the spec.
// Also remove these comments here and add your own.
// TODO: remove this comment header

// Please feel free to add any other #includes you need!
#include "recursionproblems.h"
#include <cmath>
#include <iostream>
#include "hashmap.h"
#include "map.h"
#include "random.h"
using namespace std;

int countKarelPaths(int street, int avenue) {
    // TODO: write this function
    return 0;
}

int convertStringToInteger(string exp) {
    // TODO: write this function
    return 0;
}

bool isBalanced(string exp) {
    // TODO: write this function
    return false;
}

double weightOnKnees(int row, int col, Vector<Vector<double> >& weights) {
    // TODO: write this function
    return 0.0;
}

void drawSierpinskiTriangle(GWindow& gw, double x, double y, double size, int order) {
    // TODO: write this function

}

int floodFill(GBufferedImage& image, int x, int y, int color) {
    // TODO: write this function
    return 0;
}

Vector<string> grammarGenerate(istream& input, string symbol, int times) {
    // TODO: write this function
    Vector<string> v;
    return v;
}
